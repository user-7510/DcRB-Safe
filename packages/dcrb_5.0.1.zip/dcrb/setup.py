# setup.py
from setuptools import setup, find_packages

setup(
    name="dcrb",
    version="5.0.1",
    description="Discord Remote Bot\n免責聲明：本程式工具僅供用於您有權完全使用之電腦，使用者應為自身一切操作負完全之責任。使用即代表同意。\n\n5.0.0版本不存在，但為求安裝順利，本版本為5.0.1",
    packages=find_packages(),
    package_data={
        "dcrb": ["dcrb.exe"],
    },
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "dcrb = dcrb.launcher:main",
        ],
    },
    classifiers=[],
)
