# dcrb/launcher.py
import os
import subprocess
import sys

def main():
    pkg_dir = os.path.dirname(__file__)
    exe_path = os.path.join(pkg_dir, 'dcrb.exe')
    if not os.path.isfile(exe_path):
        print(f"Error: 找不到 {exe_path}", file=sys.stderr)
        sys.exit(1)
    sys.exit(subprocess.call([exe_path] + sys.argv[1:]))
